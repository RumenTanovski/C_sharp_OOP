﻿namespace Lab2PointInRectangle
{
    public class Point
    {
        private int x;
        private int y;

        public int X { get; set; }
        public int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
