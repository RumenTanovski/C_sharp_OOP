﻿namespace Lab4HotelReservation
{
    public enum Discount
    {
        None,
        VIP = 20,
        SecondVisit = 10
    }
}
